#!/usr/bin/env python3
"""
Outlook Mail Client with Enterprise Security
Implements secure email operations with DLP and PII protection
"""

import os
import re
import json
import logging
from typing import List, Dict, Optional, Any
from dataclasses import dataclass
from enum import Enum
from datetime import datetime, timedelta
import hashlib

try:
    import msal
    import requests
    from cryptography.fernet import Fernet
    from pydantic import BaseModel, EmailStr, validator
except ImportError as e:
    print(f"Missing dependency: {e}")
    print("Install with: pip install msal requests cryptography pydantic --break-system-packages")
    raise

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class SecurityLevel(Enum):
    """Security levels for email operations"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    PARANOID = "paranoid"


class EmailClassification(Enum):
    """Email sensitivity classification"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"


@dataclass
class PIIFinding:
    """Represents found PII in content"""
    type: str
    value: str
    position: int
    redacted_value: str


@dataclass
class DLPResult:
    """Result of DLP scan"""
    has_sensitive_data: bool
    findings: List[PIIFinding]
    classification: EmailClassification
    safe_to_send: bool
    warnings: List[str]


class PIIDetector:
    """Detects and redacts PII from text"""
    
    PATTERNS = {
        'credit_card': r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
        'ssn': r'\b\d{3}-\d{2}-\d{4}\b',
        'phone': r'\b\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b',
        'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        'ip_address': r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
        'api_key': r'\b(sk|pk|api|key)[-_]?[a-zA-Z0-9]{20,}\b',
    }
    
    def detect(self, content: str) -> List[PIIFinding]:
        """Detect PII in content"""
        findings = []
        
        for pii_type, pattern in self.PATTERNS.items():
            for match in re.finditer(pattern, content, re.IGNORECASE):
                value = match.group(0)
                redacted = self._redact(value, pii_type)
                
                findings.append(PIIFinding(
                    type=pii_type,
                    value=value,
                    position=match.start(),
                    redacted_value=redacted
                ))
        
        return findings
    
    def _redact(self, value: str, pii_type: str) -> str:
        """Redact PII value"""
        if pii_type == 'credit_card':
            # Keep last 4 digits
            return 'XXXX-XXXX-XXXX-' + value[-4:]
        
        elif pii_type == 'ssn':
            # Keep last 4 digits
            return 'XXX-XX-' + value[-4:]
        
        elif pii_type == 'phone':
            # Keep last 4 digits
            digits = re.sub(r'\D', '', value)
            return f'(XXX) XXX-{digits[-4:]}'
        
        elif pii_type == 'email':
            # Mask most of local part
            local, domain = value.split('@')
            masked_local = local[0] + '***' if len(local) > 1 else '***'
            return f'{masked_local}@{domain}'
        
        elif pii_type in ('api_key', 'ip_address'):
            return '[REDACTED]'
        
        return '[REDACTED]'
    
    def redact_content(self, content: str, findings: List[PIIFinding]) -> str:
        """Redact all PII from content"""
        # Sort findings by position (descending) to maintain string positions
        sorted_findings = sorted(findings, key=lambda f: f.position, reverse=True)
        
        redacted = content
        for finding in sorted_findings:
            start = finding.position
            end = start + len(finding.value)
            redacted = redacted[:start] + finding.redacted_value + redacted[end:]
        
        return redacted


class DLPScanner:
    """Data Leak Prevention scanner"""
    
    def __init__(self):
        self.pii_detector = PIIDetector()
    
    def scan(self, content: str) -> DLPResult:
        """Scan content for sensitive data"""
        findings = self.pii_detector.detect(content)
        
        # Classify based on findings
        classification = self._classify(findings)
        
        # Determine if safe to send
        safe_to_send = classification in (
            EmailClassification.PUBLIC,
            EmailClassification.INTERNAL
        )
        
        warnings = self._generate_warnings(findings, classification)
        
        return DLPResult(
            has_sensitive_data=len(findings) > 0,
            findings=findings,
            classification=classification,
            safe_to_send=safe_to_send,
            warnings=warnings
        )
    
    def _classify(self, findings: List[PIIFinding]) -> EmailClassification:
        """Classify content based on PII findings"""
        if not findings:
            return EmailClassification.INTERNAL
        
        sensitive_types = {'credit_card', 'ssn', 'api_key'}
        has_sensitive = any(f.type in sensitive_types for f in findings)
        
        if has_sensitive:
            return EmailClassification.RESTRICTED
        
        if len(findings) > 5:
            return EmailClassification.CONFIDENTIAL
        
        return EmailClassification.INTERNAL
    
    def _generate_warnings(
        self,
        findings: List[PIIFinding],
        classification: EmailClassification
    ) -> List[str]:
        """Generate warnings based on findings"""
        warnings = []
        
        pii_counts = {}
        for finding in findings:
            pii_counts[finding.type] = pii_counts.get(finding.type, 0) + 1
        
        for pii_type, count in pii_counts.items():
            warnings.append(
                f"Found {count} {pii_type.replace('_', ' ')}(s)"
            )
        
        if classification == EmailClassification.RESTRICTED:
            warnings.append(
                "⚠️  RESTRICTED data detected. Review carefully before sending."
            )
        
        return warnings


class CredentialManager:
    """Secure credential storage and retrieval"""
    
    def __init__(self, cred_file: str = None):
        self.cred_file = cred_file or os.path.expanduser(
            '~/.codex/outlook-credentials.enc'
        )
        self._ensure_key()
    
    def _ensure_key(self):
        """Ensure encryption key exists"""
        key_file = os.path.expanduser('~/.codex/outlook.key')
        
        if not os.path.exists(key_file):
            os.makedirs(os.path.dirname(key_file), exist_ok=True)
            key = Fernet.generate_key()
            
            # Write key with restrictive permissions
            with open(key_file, 'wb') as f:
                f.write(key)
            os.chmod(key_file, 0o600)
        
        with open(key_file, 'rb') as f:
            self.cipher = Fernet(f.read())
    
    def save_credentials(self, tenant_id: str, client_id: str, client_secret: str):
        """Save credentials encrypted"""
        credentials = {
            'tenant_id': tenant_id,
            'client_id': client_id,
            'client_secret': client_secret
        }
        
        encrypted = self.cipher.encrypt(json.dumps(credentials).encode())
        
        os.makedirs(os.path.dirname(self.cred_file), exist_ok=True)
        with open(self.cred_file, 'wb') as f:
            f.write(encrypted)
        os.chmod(self.cred_file, 0o600)
        
        logger.info("Credentials saved securely")
    
    def load_credentials(self) -> Dict[str, str]:
        """Load and decrypt credentials"""
        if not os.path.exists(self.cred_file):
            raise FileNotFoundError(
                "Credentials not found. Run: python scripts/setup_credentials.py"
            )
        
        with open(self.cred_file, 'rb') as f:
            encrypted = f.read()
        
        decrypted = self.cipher.decrypt(encrypted)
        return json.loads(decrypted.decode())


class AuditLogger:
    """Audit logger for compliance"""
    
    def __init__(self, log_file: str = None):
        self.log_file = log_file or os.path.expanduser(
            '~/.codex/logs/outlook-audit.log'
        )
        os.makedirs(os.path.dirname(self.log_file), exist_ok=True)
    
    def log_operation(
        self,
        action: str,
        details: Dict[str, Any],
        success: bool = True
    ):
        """Log an email operation"""
        entry = {
            'timestamp': datetime.now().isoformat(),
            'action': action,
            'details': details,
            'success': success
        }
        
        with open(self.log_file, 'a') as f:
            f.write(json.dumps(entry) + '\n')
        
        logger.info(f"Audit log: {action} - {'Success' if success else 'Failed'}")


class OutlookClient:
    """
    Secure Outlook email client with DLP protection
    """
    
    GRAPH_ENDPOINT = "https://graph.microsoft.com/v1.0"
    
    def __init__(
        self,
        security_level: SecurityLevel = SecurityLevel.HIGH,
        auto_sanitize: bool = True
    ):
        self.security_level = security_level
        self.auto_sanitize = auto_sanitize
        
        self.cred_manager = CredentialManager()
        self.dlp_scanner = DLPScanner()
        self.audit_logger = AuditLogger()
        
        self._init_client()
    
    def _init_client(self):
        """Initialize MSAL client"""
        creds = self.cred_manager.load_credentials()
        
        self.app = msal.ConfidentialClientApplication(
            creds['client_id'],
            authority=f"https://login.microsoftonline.com/{creds['tenant_id']}",
            client_credential=creds['client_secret']
        )
        
        logger.info("Outlook client initialized")
    
    def _get_token(self) -> str:
        """Get access token"""
        result = self.app.acquire_token_for_client(
            scopes=["https://graph.microsoft.com/.default"]
        )
        
        if 'access_token' not in result:
            raise Exception(f"Authentication failed: {result.get('error_description')}")
        
        return result['access_token']
    
    def read_emails(
        self,
        folder: str = "Inbox",
        max_results: int = 10,
        auto_sanitize: bool = None
    ) -> List[Dict]:
        """Read emails with automatic sanitization"""
        sanitize = auto_sanitize if auto_sanitize is not None else self.auto_sanitize
        
        token = self._get_token()
        
        url = f"{self.GRAPH_ENDPOINT}/me/mailFolders/{folder}/messages"
        params = {'$top': max_results}
        
        response = requests.get(
            url,
            headers={'Authorization': f'Bearer {token}'},
            params=params
        )
        response.raise_for_status()
        
        emails = response.json().get('value', [])
        
        # Sanitize if requested
        if sanitize:
            emails = [self._sanitize_email(email) for email in emails]
        
        # Audit log
        self.audit_logger.log_operation(
            'read_emails',
            {'folder': folder, 'count': len(emails)}
        )
        
        return emails
    
    def _sanitize_email(self, email: Dict) -> Dict:
        """Sanitize email content"""
        if 'body' in email and 'content' in email['body']:
            content = email['body']['content']
            findings = self.dlp_scanner.pii_detector.detect(content)
            
            if findings:
                redacted = self.dlp_scanner.pii_detector.redact_content(
                    content,
                    findings
                )
                email['body']['content'] = redacted
                email['_sanitized'] = True
                email['_pii_found'] = len(findings)
        
        return email
    
    def create_draft(
        self,
        to: List[str],
        subject: str,
        body: str,
        sensitivity: str = None
    ) -> 'EmailDraft':
        """Create email draft with DLP scanning"""
        draft = EmailDraft(
            client=self,
            to=to,
            subject=subject,
            body=body,
            sensitivity=sensitivity
        )
        
        # Automatic DLP scan
        draft._dlp_result = self.dlp_scanner.scan(body)
        
        return draft
    
    def send_email(
        self,
        to: List[str],
        subject: str,
        body: str,
        require_approval: bool = True
    ):
        """Send email (requires approval by default)"""
        # DLP scan
        dlp_result = self.dlp_scanner.scan(body)
        
        if dlp_result.warnings:
            for warning in dlp_result.warnings:
                logger.warning(warning)
        
        if not dlp_result.safe_to_send and require_approval:
            print("\n⚠️  SECURITY WARNING ⚠️")
            print("This email contains sensitive data:")
            for warning in dlp_result.warnings:
                print(f"  - {warning}")
            print(f"\nClassification: {dlp_result.classification.value}")
            
            approval = input("\nSend anyway? (yes/no): ").strip().lower()
            if approval != 'yes':
                logger.info("Email send cancelled by user")
                return False
        
        # Send email
        token = self._get_token()
        
        url = f"{self.GRAPH_ENDPOINT}/me/sendMail"
        
        message = {
            "message": {
                "subject": subject,
                "body": {
                    "contentType": "Text",
                    "content": body
                },
                "toRecipients": [
                    {"emailAddress": {"address": addr}} for addr in to
                ]
            }
        }
        
        response = requests.post(
            url,
            headers={
                'Authorization': f'Bearer {token}',
                'Content-Type': 'application/json'
            },
            json=message
        )
        response.raise_for_status()
        
        # Audit log
        self.audit_logger.log_operation(
            'send_email',
            {
                'to': to,
                'subject': subject,
                'classification': dlp_result.classification.value,
                'dlp_passed': dlp_result.safe_to_send
            }
        )
        
        logger.info(f"Email sent to {', '.join(to)}")
        return True


class EmailDraft:
    """Email draft with DLP checking"""
    
    def __init__(
        self,
        client: OutlookClient,
        to: List[str],
        subject: str,
        body: str,
        sensitivity: str = None
    ):
        self.client = client
        self.to = to
        self.subject = subject
        self.body = body
        self.sensitivity = sensitivity
        self._dlp_result = None
    
    def dlp_check(self) -> DLPResult:
        """Run DLP check on draft"""
        if not self._dlp_result:
            self._dlp_result = self.client.dlp_scanner.scan(self.body)
        return self._dlp_result
    
    def send(self, require_approval: bool = True):
        """Send the draft"""
        return self.client.send_email(
            to=self.to,
            subject=self.subject,
            body=self.body,
            require_approval=require_approval
        )


if __name__ == '__main__':
    # Example usage
    print("Outlook Mail Client - Security Features Demo\n")
    
    # Initialize client
    try:
        client = OutlookClient(security_level=SecurityLevel.HIGH)
        print("✅ Client initialized successfully\n")
        
        # Example: Read emails (automatically sanitized)
        print("Reading latest emails...")
        emails = client.read_emails(max_results=5)
        
        for email in emails[:2]:
            print(f"\nSubject: {email.get('subject', 'No subject')}")
            if email.get('_sanitized'):
                print(f"⚠️  PII found and redacted: {email.get('_pii_found')} items")
        
    except FileNotFoundError:
        print("❌ Credentials not configured")
        print("Run: python scripts/setup_credentials.py")
    except Exception as e:
        print(f"❌ Error: {e}")
