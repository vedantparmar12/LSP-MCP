---
name: outlook-mail
description: Read, compose, and manage Outlook emails with enterprise security. Use when Codex needs to: (1) Read or search emails, (2) Draft or send emails, (3) Manage email folders and filters, (4) Extract information from emails, (5) Automate email workflows. Includes data leak prevention, PII detection, and secure credential handling.
metadata:
  short-description: Secure Outlook email management and automation
  version: 1.0.0
  author: Enterprise Security Team
  requires:
    - python >= 3.8
    - Microsoft Graph API access
  scopes:
    - Mail.Read
    - Mail.Send
    - Mail.ReadWrite
---

# Outlook Mail Skill

Enterprise-grade skill for managing Outlook emails with built-in security controls and data leak prevention.

## Overview

This skill enables Codex to interact with Outlook email securely, with automatic PII detection, data classification, and audit logging. It uses Microsoft Graph API with OAuth2 authentication.

## Security Features

### 1. Data Leak Prevention (DLP)
- **PII Detection**: Automatically detects and masks sensitive data
- **Content Classification**: Tags emails by sensitivity level
- **Approval Workflow**: Requires explicit approval for sensitive operations
- **Audit Logging**: Comprehensive logging of all email operations

### 2. Credential Security
- **OAuth2 Only**: No password storage, uses secure token flow
- **Token Encryption**: All tokens encrypted at rest
- **Token Refresh**: Automatic token rotation
- **Revocation Support**: Immediate token revocation capability

### 3. Access Controls
- **Scope Limiting**: Minimal required permissions only
- **Read-Only Mode**: Default to read-only operations
- **Approval Gates**: Human approval for destructive operations
- **Rate Limiting**: Prevents API abuse

## Workflow Decision Tree

### Reading Emails
**Task**: "Read my latest emails" or "Search for emails from X"
1. Check read permissions
2. Execute search/read operation
3. Scan for PII/sensitive data
4. Redact sensitive information
5. Return sanitized content

### Composing Emails
**Task**: "Draft an email to X about Y"
1. Validate recipient addresses
2. Generate draft content
3. **PAUSE for user review**
4. Scan for sensitive data
5. Apply DLP policies
6. **Request explicit send approval**
7. Send if approved

### Managing Emails
**Task**: "Move emails from X to folder Y"
1. Verify folder exists
2. Check permissions
3. Preview affected emails
4. **Request confirmation**
5. Execute move operation
6. Log action

## Usage Examples

### Safe Email Reading

```python
# Read latest emails (automatically sanitized)
from outlook_skill import OutlookClient, SecurityLevel

client = OutlookClient(security_level=SecurityLevel.HIGH)

# Automatically redacts PII
emails = client.read_emails(
    folder="Inbox",
    max_results=10,
    auto_sanitize=True  # Default: True
)

for email in emails:
    print(f"From: {email.from_address}")
    print(f"Subject: {email.subject}")
    print(f"Body: {email.sanitized_body}")  # PII redacted
    print(f"Sensitivity: {email.classification}")
```

### Secure Email Sending

```python
# Draft email (requires approval to send)
draft = client.create_draft(
    to=["colleague@company.com"],
    subject="Project Update",
    body="Status update on the project...",
    sensitivity="Normal"  # Auto-detected if not specified
)

# DLP check is automatic
dlp_result = draft.dlp_check()
if dlp_result.has_sensitive_data:
    print(f"⚠️  Sensitive data detected: {dlp_result.findings}")
    
# Requires explicit approval
if user_approves():
    draft.send()  # Requires send permission
```

### Email Search with PII Protection

```python
# Search emails with automatic sanitization
results = client.search_emails(
    query="subject:invoice",
    date_range="last 7 days",
    sanitize_results=True
)

# PII is automatically masked
for email in results:
    # Credit cards: XXXX-XXXX-XXXX-1234
    # SSN: XXX-XX-6789
    # Emails: j***@company.com
    print(email.sanitized_content)
```

## Installation & Setup

### 1. Install Dependencies

```bash
pip install msal requests cryptography pydantic --break-system-packages
```

### 2. Register App in Azure AD

Required for Microsoft Graph API access:

1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to **Azure Active Directory** → **App registrations**
3. Click **New registration**
4. Configure:
   - Name: "Codex Outlook Integration"
   - Supported account types: Single tenant
   - Redirect URI: `http://localhost:8080/callback`
5. Copy **Application (client) ID** and **Directory (tenant) ID**
6. Create **Client Secret** under Certificates & secrets
7. Grant API permissions:
   - `Mail.Read`
   - `Mail.Send` (if sending emails)
   - `Mail.ReadWrite` (if managing emails)

### 3. Configure Credentials

```bash
# Create secure credential file (encrypted)
python scripts/setup_credentials.py
```

This will prompt for:
- Tenant ID
- Client ID
- Client Secret (encrypted before storage)

Credentials stored in: `~/.codex/outlook-credentials.enc`

### 4. Test Connection

```bash
python scripts/test_connection.py
```

## Configuration

Edit `config/outlook-config.yaml`:

```yaml
# Security Settings
security:
  # Data Leak Prevention
  dlp:
    enabled: true
    pii_detection: true
    auto_redact: true
    
    # What to detect
    detect:
      - credit_cards
      - ssn
      - phone_numbers
      - email_addresses
      - ip_addresses
      - api_keys
      - passwords
    
    # Redaction style
    redaction:
      style: partial  # partial, full, hash
      preserve_format: true
  
  # Approval Requirements
  approvals:
    required_for:
      - send_email
      - delete_email
      - forward_email
      - modify_permissions
    
    timeout_seconds: 300
    
  # Audit Logging
  audit:
    enabled: true
    log_path: ~/.codex/logs/outlook-audit.log
    log_level: INFO
    include_content: false  # Don't log email bodies

# API Settings
api:
  graph_endpoint: https://graph.microsoft.com/v1.0
  timeout_seconds: 30
  max_retries: 3
  rate_limit:
    requests_per_minute: 60
    requests_per_hour: 1000

# Default Behaviors
defaults:
  max_emails_per_request: 50
  default_folder: Inbox
  auto_mark_as_read: false
  include_attachments: false  # Security: Don't auto-download
```

## Security Best Practices

### 1. Minimize Permissions

Only request permissions actually needed:

```python
# ❌ Bad - Requesting unnecessary permissions
scopes = ["Mail.ReadWrite", "Mail.Send", "Contacts.ReadWrite"]

# ✅ Good - Minimal permissions
scopes = ["Mail.Read"]  # Only read access
```

### 2. Sanitize Before Processing

Always sanitize email content before analysis:

```python
# ✅ Good - Sanitize first
email = client.read_email(email_id)
sanitized_content = email.get_sanitized_body()
analysis = analyze_text(sanitized_content)

# ❌ Bad - Processing raw content
email = client.read_email(email_id)
analysis = analyze_text(email.body)  # May contain PII
```

### 3. Use Approval Gates

Require explicit approval for sensitive operations:

```python
# ✅ Good - Requires approval
@require_approval("send_email")
def send_email(to, subject, body):
    client.send(to=to, subject=subject, body=body)

# User will be prompted:
# "⚠️  Approval required to send email to john@example.com"
# "Subject: Confidential Information"
# "Approve? (yes/no): "
```

### 4. Log All Operations

Comprehensive audit trail:

```python
# Automatic logging
client.send_email(...)

# Logs:
# [2025-12-28 10:30:00] INFO - Email sent
#   User: alice@company.com
#   To: bob@company.com
#   Subject: Project Update
#   Classification: Normal
#   DLP: Passed
#   Approval: alice@company.com
```

## PII Detection & Redaction

The skill automatically detects and redacts:

### Credit Cards
```
Original: "My card is 4532-1234-5678-9010"
Redacted: "My card is XXXX-XXXX-XXXX-9010"
```

### Social Security Numbers
```
Original: "SSN: 123-45-6789"
Redacted: "SSN: XXX-XX-6789"
```

### Email Addresses
```
Original: "Contact john.doe@company.com"
Redacted: "Contact j***@company.com"
```

### Phone Numbers
```
Original: "Call me at (555) 123-4567"
Redacted: "Call me at (XXX) XXX-4567"
```

### API Keys & Tokens
```
Original: "API key: sk_live_abcd1234efgh5678"
Redacted: "API key: [REDACTED]"
```

## Error Handling

The skill handles common errors gracefully:

```python
from outlook_skill import OutlookError, AuthenticationError, PermissionError

try:
    emails = client.read_emails()
except AuthenticationError:
    # Token expired or invalid
    print("Please re-authenticate")
    client.re_authenticate()
    
except PermissionError as e:
    # Missing required scope
    print(f"Missing permission: {e.required_scope}")
    print("Please grant additional permissions in Azure AD")
    
except OutlookError as e:
    # General error
    print(f"Error: {e.message}")
```

## Rate Limiting

Automatic rate limiting prevents API abuse:

```python
# Automatic rate limiting
for i in range(1000):
    email = client.read_email(email_ids[i])
    # Automatically throttled to stay within limits
    # No action needed from user
```

**Limits:**
- 60 requests per minute
- 1000 requests per hour
- Configurable in `outlook-config.yaml`

## Audit Logs

All operations are logged:

```json
{
  "timestamp": "2025-12-28T10:30:00Z",
  "user": "alice@company.com",
  "action": "send_email",
  "details": {
    "to": ["bob@company.com"],
    "subject": "Project Update",
    "classification": "Normal",
    "dlp_status": "Passed",
    "approval_by": "alice@company.com"
  },
  "success": true
}
```

**Log Location:** `~/.codex/logs/outlook-audit.log`

## Compliance

### GDPR Compliance
- ✅ PII detection and redaction
- ✅ Right to access (read emails)
- ✅ Right to erasure (delete emails)
- ✅ Audit logging
- ✅ Data minimization (minimal scopes)

### SOC 2 Compliance
- ✅ Access controls (OAuth2)
- ✅ Audit logging
- ✅ Encryption at rest (credentials)
- ✅ Approval workflows

## Troubleshooting

### "Authentication failed"
**Solution:** Re-run credential setup:
```bash
python scripts/setup_credentials.py --force
```

### "Permission denied"
**Solution:** Grant required permissions in Azure AD:
1. Go to Azure Portal → App registrations
2. Select your app
3. API permissions → Add permission
4. Select required scopes

### "Rate limit exceeded"
**Solution:** Adjust rate limits in config or wait:
```yaml
api:
  rate_limit:
    requests_per_minute: 30  # Reduce if needed
```

## Advanced Usage

See [`references/advanced-patterns.md`](references/advanced-patterns.md) for:
- Bulk email processing
- Email classification rules
- Custom DLP policies
- Integration with other tools

## Scripts Reference

- `scripts/setup_credentials.py` - Initial credential configuration
- `scripts/test_connection.py` - Test Microsoft Graph connection
- `scripts/outlook_client.py` - Main client implementation
- `scripts/dlp_scanner.py` - Data leak prevention scanner
- `scripts/pii_detector.py` - PII detection engine

## Security Incident Response

If you suspect a security incident:

1. **Immediately revoke tokens** in Azure AD
2. Check audit logs: `~/.codex/logs/outlook-audit.log`
3. Review recent operations
4. Report to security team
5. Rotate credentials: `python scripts/setup_credentials.py --rotate`

## Limitations

- **No attachment auto-download**: Security policy (can be changed)
- **Send requires approval**: Cannot be disabled for production
- **Rate limits**: Microsoft Graph API limits apply
- **OAuth only**: No basic auth support (by design)

## Support

For issues or questions:
- Check troubleshooting section above
- Review audit logs
- Contact IT security team for credential issues

---

**Remember:** This skill handles sensitive corporate data. Always follow your organization's security policies and never disable security features without approval.
