---
name: slack-channel
description: Read, post, and manage Slack messages with enterprise security. Use when Codex needs to: (1) Read channel messages or threads, (2) Post messages or replies, (3) Search for information in Slack, (4) Manage channels and users, (5) Automate Slack workflows. Includes data leak prevention, PII detection, secure credential handling, and rate limiting.
metadata:
  short-description: Secure Slack message management and automation
  version: 1.0.0
  author: Enterprise Security Team
  requires:
    - python >= 3.8
    - Slack API access
  scopes:
    - channels:read
    - channels:history
    - chat:write
    - users:read
---

# Slack Channel Skill

Enterprise-grade skill for managing Slack messages with built-in security controls, data leak prevention, and compliance features.

## Overview

This skill enables Codex to interact with Slack securely, with automatic PII detection, content moderation, approval workflows, and comprehensive audit logging. It uses Slack Web API with OAuth2 authentication.

## Security Features

### 1. Data Leak Prevention (DLP)
- **PII Detection**: Automatically detects and redacts sensitive data
- **Content Moderation**: Filters inappropriate content
- **Approval Workflow**: Requires explicit approval for public channels
- **Message Retention**: Respects corporate retention policies
- **Audit Logging**: Comprehensive logging of all Slack operations

### 2. Credential Security
- **OAuth2 Tokens**: Secure token-based authentication
- **Token Encryption**: All tokens encrypted at rest
- **Auto-Refresh**: Automatic token rotation
- **Workspace Validation**: Verify workspace before operations
- **Scope Limitation**: Minimal required permissions

### 3. Access Controls
- **Channel Restrictions**: Limit access to specific channels
- **User Validation**: Verify user permissions
- **Read-Only Mode**: Default to read-only operations
- **Approval Gates**: Human approval for public posts
- **Rate Limiting**: Prevents API abuse and spam

### 4. Compliance Features
- **Message Retention**: Auto-delete based on policy
- **Audit Trail**: Full history of operations
- **GDPR Support**: PII redaction and data export
- **SOC 2 Controls**: Access logging and encryption

## Workflow Decision Tree

### Reading Messages
**Task**: "Read messages from #engineering" or "Search for discussions about X"
1. Validate channel access
2. Execute read/search operation
3. Scan for PII/sensitive data
4. Redact sensitive information
5. Return sanitized content

### Posting Messages
**Task**: "Post update to #general"
1. Validate channel permissions
2. Generate message content
3. **PAUSE for user review**
4. Scan for sensitive data
5. Apply content moderation
6. Check if public channel
7. **Request approval if public**
8. Post if approved

### Thread Management
**Task**: "Reply to thread about X"
1. Find thread
2. Verify permissions
3. Generate reply
4. DLP scan
5. **Request approval**
6. Post reply

## Usage Examples

### Safe Message Reading

```python
# Read channel messages (automatically sanitized)
from slack_skill import SlackClient, SecurityLevel

client = SlackClient(
    workspace="mycompany",
    security_level=SecurityLevel.HIGH
)

# Automatically redacts PII
messages = client.read_messages(
    channel="#engineering",
    limit=50,
    auto_sanitize=True  # Default: True
)

for msg in messages:
    print(f"User: {msg.user}")
    print(f"Message: {msg.sanitized_text}")  # PII redacted
    print(f"Sentiment: {msg.sentiment}")
    print(f"Classification: {msg.classification}")
```

### Secure Message Posting

```python
# Post message (requires approval for public channels)
result = client.post_message(
    channel="#general",
    text="Team update: Project milestone completed!",
    require_approval=True  # Default for public channels
)

# DLP check is automatic
if result.dlp_warnings:
    for warning in result.dlp_warnings:
        print(f"⚠️  {warning}")

# For public channels, will prompt:
# "⚠️  Posting to PUBLIC channel: #general"
# "Approve? (yes/no): "
```

### Search with PII Protection

```python
# Search messages with automatic sanitization
results = client.search_messages(
    query="invoice",
    in_channels=["#finance", "#accounting"],
    date_range="last 30 days",
    sanitize_results=True
)

# Sensitive data automatically masked
for result in results:
    print(f"Channel: {result.channel}")
    print(f"Message: {result.sanitized_text}")
    # Credit cards: XXXX-XXXX-XXXX-1234
    # SSN: XXX-XX-6789
    # Tokens: [REDACTED]
```

### Thread Participation

```python
# Reply to thread with safety checks
thread = client.find_thread(
    channel="#support",
    query="customer issue #12345"
)

if thread:
    client.reply_to_thread(
        thread_ts=thread.ts,
        channel=thread.channel,
        text="I've resolved this issue. Updated the ticket.",
        require_approval=False  # Not needed for replies
    )
```

## Installation & Setup

### 1. Install Dependencies

```bash
pip install slack-sdk cryptography pydantic pyyaml --break-system-packages
```

### 2. Create Slack App

Required for Slack API access:

1. Go to [Slack API](https://api.slack.com/apps)
2. Click **Create New App**
3. Choose **From scratch**
4. Configure:
   - App Name: "Codex Slack Integration"
   - Workspace: Select your workspace
5. Navigate to **OAuth & Permissions**
6. Add Bot Token Scopes:
   - `channels:read` (read public channels)
   - `channels:history` (read messages)
   - `chat:write` (post messages)
   - `users:read` (read user info)
   - `search:read` (search messages)
7. Install app to workspace
8. Copy **Bot User OAuth Token**

### 3. Configure Credentials

```bash
# Create secure credential file (encrypted)
python scripts/setup_slack_credentials.py
```

This will prompt for:
- Workspace name
- Bot Token (encrypted before storage)
- App Token (if using Socket Mode)

Credentials stored in: `~/.codex/slack-credentials.enc`

### 4. Test Connection

```bash
python scripts/test_slack_connection.py
```

## Configuration

Edit `config/slack-config.yaml`:

```yaml
# Security Settings
security:
  # Data Leak Prevention
  dlp:
    enabled: true
    pii_detection: true
    auto_redact: true
    
    # What to detect
    detect:
      - credit_cards
      - ssn
      - phone_numbers
      - email_addresses
      - api_keys
      - passwords
      - access_tokens
    
    # Content moderation
    moderation:
      enabled: true
      check_profanity: true
      check_harassment: false  # Requires ML model
  
  # Approval Requirements
  approvals:
    # Require approval for public channels
    public_channels: true
    
    # Specific channels requiring approval
    require_for_channels:
      - "#announcements"
      - "#general"
      - "#all-hands"
    
    timeout_seconds: 300
    
  # Channel Restrictions
  restrictions:
    # Channels Codex can access
    allowed_channels:
      - "#engineering"
      - "#support"
      - "#dev-*"  # Wildcard pattern
    
    # Channels Codex cannot access
    blocked_channels:
      - "#executive"
      - "#hr"
      - "#finance"
  
  # Audit Logging
  audit:
    enabled: true
    log_path: ~/.codex/logs/slack-audit.log
    log_level: INFO
    include_message_content: false  # Don't log full messages

# API Settings
api:
  base_url: https://slack.com/api
  timeout_seconds: 30
  max_retries: 3
  
  rate_limit:
    messages_per_minute: 20
    messages_per_hour: 500
    
  # Throttling
  throttle:
    enabled: true
    delay_between_posts_ms: 1000  # 1 second between posts

# Default Behaviors
defaults:
  max_messages_per_request: 100
  default_limit: 50
  auto_mark_as_read: false
  include_threads: true
  thread_reply_broadcast: false  # Don't broadcast replies
  
# Message Formatting
formatting:
  use_blocks: true
  use_markdown: true
  escape_mentions: true  # Prevent unintended @mentions
  
# Retention Policy
retention:
  enabled: false
  delete_after_days: 90
  exclude_channels:
    - "#legal"
    - "#compliance"
```

## Security Best Practices

### 1. Minimize Permissions

Only request scopes actually needed:

```python
# ❌ Bad - Requesting unnecessary permissions
scopes = ["channels:read", "channels:write", "users:write", "admin"]

# ✅ Good - Minimal permissions
scopes = ["channels:read", "channels:history"]  # Read-only
```

### 2. Sanitize Before Processing

Always sanitize messages before analysis:

```python
# ✅ Good - Sanitize first
messages = client.read_messages("#support")
for msg in messages:
    sanitized = msg.get_sanitized_text()
    analysis = analyze_sentiment(sanitized)

# ❌ Bad - Processing raw content
messages = client.read_messages("#support")
for msg in messages:
    analysis = analyze_sentiment(msg.text)  # May contain PII
```

### 3. Use Approval Gates for Public Channels

Require explicit approval for public visibility:

```python
# ✅ Good - Requires approval for public channels
@require_approval_if_public
def post_update(channel, message):
    client.post_message(channel=channel, text=message)

# User will be prompted:
# "⚠️  Posting to PUBLIC channel: #general"
# "Message will be visible to 1,234 members"
# "Approve? (yes/no): "
```

### 4. Validate Channel Access

Check permissions before operations:

```python
# ✅ Good - Validate access
if client.can_access_channel("#engineering"):
    messages = client.read_messages("#engineering")
else:
    print("Access denied to #engineering")

# ❌ Bad - No validation
messages = client.read_messages("#engineering")  # May fail
```

### 5. Comprehensive Logging

Audit trail for all operations:

```python
# Automatic logging
client.post_message(...)

# Logs:
# [2025-12-28 10:30:00] INFO - Message posted
#   User: alice
#   Channel: #engineering (public)
#   Classification: Normal
#   DLP: Passed
#   Approval: alice
#   Message ID: 1234.5678
```

## PII Detection & Redaction

The skill automatically detects and redacts:

### Credit Cards
```
Original: "Payment via 4532-1234-5678-9010"
Redacted: "Payment via XXXX-XXXX-XXXX-9010"
```

### Social Security Numbers
```
Original: "Employee SSN: 123-45-6789"
Redacted: "Employee SSN: XXX-XX-6789"
```

### Tokens & API Keys
```
Original: "Token: xoxb-1234567890-abcdefghijk"
Redacted: "Token: [REDACTED]"
```

### Email Addresses
```
Original: "Contact john.doe@company.com"
Redacted: "Contact j***@company.com"
```

## Content Moderation

Optional content moderation for:
- Profanity filtering
- Harassment detection
- Spam prevention
- Link validation

```yaml
security:
  moderation:
    enabled: true
    check_profanity: true
    block_external_links: false
    check_spam_patterns: true
```

## Rate Limiting

Automatic rate limiting prevents:
- API quota exhaustion
- Spam detection
- Channel flooding

```python
# Automatic rate limiting
for i in range(100):
    client.post_message(
        channel="#test",
        text=f"Message {i}"
    )
    # Automatically throttled (1 second delay)
    # No action needed from user
```

**Limits:**
- 20 messages per minute
- 500 messages per hour
- 1 second minimum delay between posts

## Error Handling

The skill handles common errors gracefully:

```python
from slack_skill import SlackError, AuthenticationError, RateLimitError

try:
    messages = client.read_messages("#engineering")
except AuthenticationError:
    # Invalid token
    print("Please re-authenticate")
    client.re_authenticate()
    
except ChannelNotFoundError as e:
    # Channel doesn't exist or no access
    print(f"Cannot access channel: {e.channel}")
    
except RateLimitError as e:
    # Hit rate limit
    print(f"Rate limited. Retry after {e.retry_after} seconds")
    
except SlackError as e:
    # General error
    print(f"Error: {e.message}")
```

## Audit Logs

All operations are logged:

```json
{
  "timestamp": "2025-12-28T10:30:00Z",
  "user": "alice",
  "workspace": "mycompany",
  "action": "post_message",
  "details": {
    "channel": "#general",
    "channel_type": "public",
    "member_count": 1234,
    "classification": "Normal",
    "dlp_status": "Passed",
    "approval_by": "alice",
    "message_id": "1234.5678"
  },
  "success": true
}
```

**Log Location:** `~/.codex/logs/slack-audit.log`

## Compliance

### GDPR Compliance
- ✅ PII detection and redaction
- ✅ Right to access (read messages)
- ✅ Right to erasure (delete messages)
- ✅ Audit logging
- ✅ Data minimization (minimal scopes)

### SOC 2 Compliance
- ✅ Access controls (OAuth2, channel restrictions)
- ✅ Audit logging
- ✅ Encryption at rest (credentials)
- ✅ Approval workflows
- ✅ Rate limiting

### Slack Enterprise Grid
- Compatible with Enterprise Grid
- Respects workspace data residency
- Supports DLP policies
- Audit log integration

## Advanced Features

### Message Threading

```python
# Create threaded conversation
parent = client.post_message(
    channel="#support",
    text="New customer issue reported"
)

# Reply in thread
client.reply_to_thread(
    thread_ts=parent.ts,
    channel="#support",
    text="I'm investigating this issue"
)
```

### Message Formatting

```python
# Rich formatting with blocks
client.post_message(
    channel="#engineering",
    blocks=[
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "*Deployment Complete* ✅"
            }
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": "*Version:*\n2.1.0"},
                {"type": "mrkdwn", "text": "*Status:*\nSuccessful"}
            ]
        }
    ]
)
```

### Scheduled Messages

```python
# Schedule message for later
client.schedule_message(
    channel="#announcements",
    text="Weekly team update",
    post_at="2025-12-29T09:00:00",
    require_approval=True
)
```

## Troubleshooting

### "Invalid token"
**Solution:** Re-run credential setup:
```bash
python scripts/setup_slack_credentials.py --force
```

### "Channel not found"
**Solution:** Check channel name and permissions:
```python
# Verify channel exists
channels = client.list_channels()
print([ch.name for ch in channels])
```

### "Rate limit exceeded"
**Solution:** Adjust rate limits in config or wait:
```yaml
api:
  rate_limit:
    messages_per_minute: 10  # Reduce if needed
```

### "Missing scope"
**Solution:** Add required scope in Slack app settings:
1. Go to Slack API → Your App → OAuth & Permissions
2. Add missing scope under Bot Token Scopes
3. Reinstall app to workspace

## Advanced Usage

See [`references/slack-patterns.md`](references/slack-patterns.md) for:
- Bulk message processing
- Custom DLP policies
- Integration with other tools
- Advanced threading strategies

## Scripts Reference

- `scripts/setup_slack_credentials.py` - Initial credential configuration
- `scripts/test_slack_connection.py` - Test Slack connection
- `scripts/slack_client.py` - Main client implementation
- `scripts/dlp_scanner.py` - Data leak prevention scanner (shared with Outlook)
- `scripts/pii_detector.py` - PII detection engine (shared with Outlook)

## Security Incident Response

If you suspect a security incident:

1. **Immediately revoke token** in Slack app settings
2. Check audit logs: `~/.codex/logs/slack-audit.log`
3. Review recent operations
4. Report to security team
5. Rotate credentials: `python scripts/setup_slack_credentials.py --rotate`

## Limitations

- **Rate limits**: Slack API limits apply (configurable)
- **Message editing**: Requires additional scope
- **File uploads**: Not supported by default (security)
- **DM access**: Requires user consent and additional scopes
- **Admin operations**: Requires admin token

## Best Practices Summary

1. ✅ **Always use approval gates** for public channels
2. ✅ **Enable DLP scanning** for all messages
3. ✅ **Restrict channel access** to necessary channels only
4. ✅ **Monitor audit logs** regularly
5. ✅ **Keep tokens encrypted** and rotated
6. ✅ **Use minimal scopes** required for operations
7. ✅ **Test in private channels** before public deployment
8. ✅ **Document** all automated workflows

---

**Remember:** Slack is a public communication platform within your organization. Always follow your company's communication policies and never disable security features without approval.
