#!/usr/bin/env python3
"""
Slack Channel Client with Enterprise Security
Implements secure messaging with DLP and content moderation
"""

import os
import json
import logging
from typing import List, Dict, Optional
from dataclasses import dataclass
from enum import Enum
from datetime import datetime

try:
    from slack_sdk import WebClient
    from slack_sdk.errors import SlackApiError
    from cryptography.fernet import Fernet
    import sys
    # Import shared DLP components from Outlook skill
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../outlook-mail/scripts'))
    from outlook_client import PIIDetector, DLPScanner, SecurityLevel, EmailClassification
except ImportError as e:
    print(f"Missing dependency: {e}")
    print("Install: pip install slack-sdk cryptography pydantic pyyaml --break-system-packages")
    raise

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ChannelType(Enum):
    PUBLIC = "public"
    PRIVATE = "private"
    DM = "dm"
    MPIM = "mpim"


@dataclass
class SlackMessage:
    """Sanitized Slack message"""
    ts: str
    user: str
    channel: str
    text: str
    sanitized_text: str
    thread_ts: Optional[str]
    classification: EmailClassification
    pii_found: int
    channel_type: ChannelType


class SlackCredentialManager:
    """Secure Slack credential storage"""
    
    def __init__(self, cred_file: str = None):
        self.cred_file = cred_file or os.path.expanduser('~/.codex/slack-credentials.enc')
        self._ensure_key()
    
    def _ensure_key(self):
        key_file = os.path.expanduser('~/.codex/slack.key')
        if not os.path.exists(key_file):
            os.makedirs(os.path.dirname(key_file), exist_ok=True)
            key = Fernet.generate_key()
            with open(key_file, 'wb') as f:
                f.write(key)
            os.chmod(key_file, 0o600)
        
        with open(key_file, 'rb') as f:
            self.cipher = Fernet(f.read())
    
    def save_credentials(self, workspace: str, bot_token: str):
        credentials = {'workspace': workspace, 'bot_token': bot_token}
        encrypted = self.cipher.encrypt(json.dumps(credentials).encode())
        os.makedirs(os.path.dirname(self.cred_file), exist_ok=True)
        with open(self.cred_file, 'wb') as f:
            f.write(encrypted)
        os.chmod(self.cred_file, 0o600)
        logger.info("Slack credentials saved securely")
    
    def load_credentials(self) -> Dict[str, str]:
        if not os.path.exists(self.cred_file):
            raise FileNotFoundError("Run: python scripts/setup_slack_credentials.py")
        with open(self.cred_file, 'rb') as f:
            encrypted = f.read()
        decrypted = self.cipher.decrypt(encrypted)
        return json.loads(decrypted.decode())


class SlackAuditLogger:
    """Audit logger for Slack operations"""
    
    def __init__(self, log_file: str = None):
        self.log_file = log_file or os.path.expanduser('~/.codex/logs/slack-audit.log')
        os.makedirs(os.path.dirname(self.log_file), exist_ok=True)
    
    def log_operation(self, action: str, details: Dict, success: bool = True):
        entry = {
            'timestamp': datetime.now().isoformat(),
            'action': action,
            'details': details,
            'success': success
        }
        with open(self.log_file, 'a') as f:
            f.write(json.dumps(entry) + '\n')
        logger.info(f"Audit: {action} - {'Success' if success else 'Failed'}")


class SlackClient:
    """Secure Slack client with DLP protection"""
    
    def __init__(self, workspace: str = None, security_level: SecurityLevel = SecurityLevel.HIGH):
        self.security_level = security_level
        self.cred_manager = SlackCredentialManager()
        self.dlp_scanner = DLPScanner()
        self.audit_logger = SlackAuditLogger()
        self._init_client(workspace)
    
    def _init_client(self, workspace: str = None):
        creds = self.cred_manager.load_credentials()
        if workspace and creds['workspace'] != workspace:
            raise ValueError(f"Workspace mismatch: {workspace} != {creds['workspace']}")
        self.workspace = creds['workspace']
        self.client = WebClient(token=creds['bot_token'])
        logger.info(f"Slack client initialized for workspace: {self.workspace}")
    
    def read_messages(self, channel: str, limit: int = 50, auto_sanitize: bool = True) -> List[SlackMessage]:
        """Read channel messages with sanitization"""
        try:
            # Get channel ID
            channel_id = self._resolve_channel(channel)
            
            # Read messages
            response = self.client.conversations_history(channel=channel_id, limit=limit)
            messages = response['messages']
            
            # Get channel info for classification
            channel_info = self.client.conversations_info(channel=channel_id)
            is_public = not channel_info['channel']['is_private']
            
            # Process messages
            result = []
            for msg in messages:
                sanitized = self._sanitize_message(msg, is_public) if auto_sanitize else msg
                result.append(sanitized)
            
            # Audit log
            self.audit_logger.log_operation('read_messages', {'channel': channel, 'count': len(result)})
            return result
            
        except SlackApiError as e:
            logger.error(f"Slack API error: {e.response['error']}")
            raise
    
    def _sanitize_message(self, msg: Dict, is_public: bool) -> SlackMessage:
        """Sanitize message content"""
        text = msg.get('text', '')
        findings = self.dlp_scanner.pii_detector.detect(text)
        
        sanitized_text = text
        if findings:
            sanitized_text = self.dlp_scanner.pii_detector.redact_content(text, findings)
        
        dlp_result = self.dlp_scanner.scan(text)
        
        return SlackMessage(
            ts=msg.get('ts', ''),
            user=msg.get('user', 'unknown'),
            channel=msg.get('channel', ''),
            text=text,
            sanitized_text=sanitized_text,
            thread_ts=msg.get('thread_ts'),
            classification=dlp_result.classification,
            pii_found=len(findings),
            channel_type=ChannelType.PUBLIC if is_public else ChannelType.PRIVATE
        )
    
    def post_message(self, channel: str, text: str, require_approval: bool = None) -> Dict:
        """Post message with DLP and approval"""
        # DLP scan
        dlp_result = self.dlp_scanner.scan(text)
        
        # Check if public channel
        channel_id = self._resolve_channel(channel)
        channel_info = self.client.conversations_info(channel=channel_id)
        is_public = not channel_info['channel']['is_private']
        member_count = channel_info['channel'].get('num_members', 0)
        
        # Approval required for public channels by default
        needs_approval = require_approval if require_approval is not None else is_public
        
        if dlp_result.warnings:
            for warning in dlp_result.warnings:
                logger.warning(warning)
        
        if needs_approval:
            print(f"\n⚠️  POSTING TO {'PUBLIC' if is_public else 'PRIVATE'} CHANNEL ⚠️")
            print(f"Channel: {channel}")
            if is_public:
                print(f"Visibility: {member_count} members")
            print(f"Classification: {dlp_result.classification.value}")
            if dlp_result.warnings:
                print("\nSecurity warnings:")
                for warning in dlp_result.warnings:
                    print(f"  - {warning}")
            
            approval = input("\nPost message? (yes/no): ").strip().lower()
            if approval != 'yes':
                logger.info("Message post cancelled by user")
                return {'ok': False, 'cancelled': True}
        
        # Post message
        response = self.client.chat_postMessage(channel=channel_id, text=text)
        
        # Audit log
        self.audit_logger.log_operation('post_message', {
            'channel': channel,
            'is_public': is_public,
            'classification': dlp_result.classification.value,
            'dlp_passed': dlp_result.safe_to_send,
            'message_ts': response.get('ts')
        })
        
        logger.info(f"Message posted to {channel}")
        return response
    
    def _resolve_channel(self, channel: str) -> str:
        """Resolve channel name to ID"""
        if channel.startswith('C') or channel.startswith('D'):
            return channel  # Already an ID
        channel_name = channel.lstrip('#')
        response = self.client.conversations_list(types="public_channel,private_channel")
        for ch in response['channels']:
            if ch['name'] == channel_name:
                return ch['id']
        raise ValueError(f"Channel not found: {channel}")


if __name__ == '__main__':
    print("Slack Client - Security Features Demo\n")
    try:
        client = SlackClient(security_level=SecurityLevel.HIGH)
        print("✅ Client initialized\n")
        
        # Example: Read messages
        print("Reading messages from #general...")
        messages = client.read_messages("#general", limit=5)
        for msg in messages[:2]:
            print(f"\nUser: {msg.user}")
            print(f"Text: {msg.sanitized_text[:100]}...")
            if msg.pii_found > 0:
                print(f"⚠️  PII redacted: {msg.pii_found} items")
    except FileNotFoundError:
        print("❌ Credentials not configured")
        print("Run: python scripts/setup_slack_credentials.py")
    except Exception as e:
        print(f"❌ Error: {e}")
