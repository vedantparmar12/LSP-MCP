# Codex Skills: Outlook Mail & Slack Channel

Enterprise-grade skills for OpenAI Codex with production security features.

## Overview

Two production-ready skills following the [OpenAI Agent Skills specification](https://agentskills.io):

1. **outlook-mail** - Secure Outlook email management
2. **slack-channel** - Secure Slack messaging and automation

Both skills include:
- ✅ Data Leak Prevention (DLP)
- ✅ PII Detection & Redaction
- ✅ Approval Workflows
- ✅ Audit Logging
- ✅ Encrypted Credential Storage
- ✅ Rate Limiting
- ✅ GDPR & SOC 2 Compliance

## Quick Start

### Installation

```bash
# Extract skills
tar -xzf codex-outlook-slack-skills.tar.gz

# Choose installation location based on scope
# For user-level (recommended for testing):
cp -r codex-skills/* ~/.codex/skills/

# For repository-level:
cp -r codex-skills/* .codex/skills/

# For system-level (requires sudo):
sudo cp -r codex-skills/* /etc/codex/skills/
```

### Outlook Mail Setup

```bash
cd ~/.codex/skills/outlook-mail

# Install dependencies
pip install msal requests cryptography pydantic --break-system-packages

# Configure credentials (Azure AD app required)
python scripts/setup_credentials.py

# Test connection
python scripts/test_connection.py
```

### Slack Channel Setup

```bash
cd ~/.codex/skills/slack-channel

# Install dependencies
pip install slack-sdk cryptography pydantic pyyaml --break-system-packages

# Configure credentials (Slack app required)
python scripts/setup_slack_credentials.py

# Test connection
python scripts/test_slack_connection.py
```

## Usage in Codex

### Explicit Invocation

```bash
# In Codex CLI
$ /skills

# Or mention the skill
$ $outlook-mail read my latest emails

$ $slack-channel post update to #engineering channel
```

### Implicit Invocation

Codex will automatically use these skills when appropriate:

```
"Read my emails from yesterday"
→ Uses $outlook-mail

"Send a message to the team slack about deployment"
→ Uses $slack-channel
```

## Features

### Outlook Mail Skill

**Read Operations:**
- Read inbox, sent items, or any folder
- Search emails by subject, sender, date
- Extract information from emails
- Automatic PII redaction

**Write Operations:**
- Draft emails (requires review)
- Send emails (requires approval)
- Reply to emails
- Forward with approval

**Security:**
- OAuth2 authentication only
- Automatic PII detection (SSN, credit cards, etc.)
- DLP scanning before send
- Encrypted credential storage
- Full audit logging

**Example:**
```
User: "Read emails about project alpha from last week"

Codex: [Uses $outlook-mail]
Found 5 emails about project alpha:
1. From: john@company.com - "Project Alpha Update"
2. From: alice@company.com - "Alpha Milestone Complete"
...
[All PII automatically redacted]
```

### Slack Channel Skill

**Read Operations:**
- Read public/private channels
- Search message history
- Find threaded conversations
- Automatic sanitization

**Write Operations:**
- Post messages (approval for public)
- Reply to threads
- Schedule messages
- Rich formatting support

**Security:**
- OAuth2 bot tokens
- Public channel approval gates
- Content moderation
- PII detection and redaction
- Rate limiting (20 msg/min)
- Full audit trail

**Example:**
```
User: "Post deployment update to #engineering"

Codex: [Uses $slack-channel]
Draft message: "Deployment v2.1.0 completed successfully"

⚠️ POSTING TO PUBLIC CHANNEL ⚠️
Channel: #engineering
Visibility: 156 members
Classification: Normal

Post message? (yes/no): yes

✅ Posted to #engineering
```

## Security Architecture

### Data Leak Prevention

Both skills use the same DLP engine:

```python
class PIIDetector:
    PATTERNS = {
        'credit_card': r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
        'ssn': r'\b\d{3}-\d{2}-\d{4}\b',
        'phone': r'\b\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b',
        'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        'api_key': r'\b(sk|pk|api|key)[-_]?[a-zA-Z0-9]{20,}\b',
    }
```

**Redaction Examples:**
```
Credit Card: 4532-1234-5678-9010  → XXXX-XXXX-XXXX-9010
SSN:         123-45-6789          → XXX-XX-6789
Email:       john.doe@company.com → j***@company.com
API Key:     sk_live_abc123...    → [REDACTED]
```

### Approval Workflows

**Automatic approval required for:**
- Sending emails
- Posting to public Slack channels
- Forwarding emails
- Deleting messages
- Operations with sensitive data

**Example approval prompt:**
```
⚠️  APPROVAL REQUIRED ⚠️

Action: Send email
To: team@company.com
Subject: Quarterly Results
Classification: CONFIDENTIAL

Security warnings:
  - Found 2 credit card number(s)
  - Found 1 api key(s)

Sensitive data will be sent.
Approve? (yes/no):
```

### Credential Security

**Storage:**
```
~/.codex/
├── outlook-credentials.enc  # AES-256 encrypted
├── slack-credentials.enc    # AES-256 encrypted
├── outlook.key              # Encryption key (chmod 600)
└── slack.key                # Encryption key (chmod 600)
```

**Features:**
- AES-256 encryption at rest
- File permissions: 0600 (owner read/write only)
- No plaintext passwords ever stored
- OAuth2 tokens only
- Automatic token refresh

### Audit Logging

**Log Format:**
```json
{
  "timestamp": "2025-12-28T10:30:00Z",
  "action": "send_email",
  "details": {
    "to": ["colleague@company.com"],
    "subject": "Project Update",
    "classification": "Normal",
    "dlp_status": "Passed",
    "approval_by": "user@company.com"
  },
  "success": true
}
```

**Log Locations:**
```
~/.codex/logs/
├── outlook-audit.log
└── slack-audit.log
```

## Configuration

### Outlook Configuration

`config/outlook-config.yaml`:

```yaml
security:
  dlp:
    enabled: true
    pii_detection: true
    auto_redact: true
  
  approvals:
    required_for:
      - send_email
      - delete_email
      - forward_email
  
  audit:
    enabled: true
    log_level: INFO

api:
  graph_endpoint: https://graph.microsoft.com/v1.0
  rate_limit:
    requests_per_minute: 60
```

### Slack Configuration

`config/slack-config.yaml`:

```yaml
security:
  dlp:
    enabled: true
    pii_detection: true
  
  approvals:
    public_channels: true
    require_for_channels:
      - "#announcements"
      - "#general"
  
  restrictions:
    allowed_channels:
      - "#engineering"
      - "#dev-*"
    blocked_channels:
      - "#executive"
      - "#hr"

api:
  rate_limit:
    messages_per_minute: 20
    messages_per_hour: 500
```

## Compliance

### GDPR Compliance

✅ **Right to Access**: Read emails/messages
✅ **Right to Erasure**: Delete functionality
✅ **Data Minimization**: Minimal API scopes
✅ **Privacy by Design**: PII redaction built-in
✅ **Audit Trail**: Complete operation logging
✅ **Encryption**: Credentials encrypted at rest

### SOC 2 Compliance

✅ **Access Controls**: OAuth2, role-based
✅ **Monitoring**: Comprehensive audit logs
✅ **Encryption**: At-rest and in-transit
✅ **Approval Workflows**: Human-in-the-loop
✅ **Rate Limiting**: Abuse prevention

## Troubleshooting

### Outlook Issues

**"Authentication failed"**
```bash
python scripts/setup_credentials.py --force
```

**"Permission denied"**
1. Go to Azure Portal → App registrations
2. Add required API permissions
3. Grant admin consent

### Slack Issues

**"Invalid token"**
```bash
python scripts/setup_slack_credentials.py --force
```

**"Channel not found"**
```python
# List available channels
from slack_skill import SlackClient
client = SlackClient()
channels = client.list_channels()
print([ch.name for ch in channels])
```

## Advanced Usage

### Custom DLP Policies

Add custom patterns to detect:

```python
# In outlook_client.py or slack_client.py
PIIDetector.PATTERNS['custom_id'] = r'\bCUST-\d{6}\b'
```

### Integration with Other Tools

Both skills can be integrated with:
- Zapier workflows
- GitHub Actions
- CI/CD pipelines
- Custom automation scripts

### Batch Operations

```python
# Outlook: Bulk email processing
client = OutlookClient()
emails = client.read_emails(folder="Inbox", max_results=100)
for email in emails:
    if "urgent" in email.subject.lower():
        # Process urgent emails
        pass
```

## File Structure

```
codex-skills/
├── outlook-mail/
│   ├── SKILL.md                    # Main skill definition
│   ├── scripts/
│   │   ├── outlook_client.py       # Implementation
│   │   ├── setup_credentials.py    # Setup tool
│   │   └── test_connection.py      # Test tool
│   ├── references/
│   │   └── advanced-patterns.md    # Advanced usage
│   ├── config/
│   │   └── outlook-config.yaml     # Configuration
│   └── assets/
│
└── slack-channel/
    ├── SKILL.md                    # Main skill definition
    ├── scripts/
    │   ├── slack_client.py         # Implementation
    │   ├── setup_slack_credentials.py
    │   └── test_slack_connection.py
    ├── references/
    │   └── slack-patterns.md
    └── config/
        └── slack-config.yaml
```

## Best Practices

### Security

1. ✅ **Never disable security features** without explicit approval
2. ✅ **Review all approval prompts** carefully
3. ✅ **Monitor audit logs** regularly
4. ✅ **Rotate credentials** periodically
5. ✅ **Use minimal permissions** (least privilege)
6. ✅ **Test in private channels** first
7. ✅ **Keep skills updated** with latest security patches

### Operations

1. Start with read-only operations
2. Test with small datasets first
3. Review DLP warnings carefully
4. Use explicit invocation for critical tasks
5. Check audit logs after operations
6. Document any configuration changes

## Support

For issues or questions:

1. Check `SKILL.md` for each skill
2. Review troubleshooting section
3. Check audit logs for errors
4. Contact IT security team for credential issues

## License

Enterprise use only. Follow your organization's security policies.

## Version History

- **v1.0.0** (2025-12-28) - Initial release
  - Outlook mail skill with DLP
  - Slack channel skill with DLP
  - Full security implementation
  - Compliance features (GDPR, SOC 2)
  - Audit logging
  - Approval workflows

---

**⚠️  Security Notice:** These skills handle sensitive corporate data. Always follow your organization's security policies and data governance requirements.
