import { MultiLayerCache } from '../src/cache/multi-layer-cache';
import { ContentHasher } from '../src/cache/content-hash';

describe('MultiLayerCache', () => {
  let cache: MultiLayerCache;
  
  beforeEach(() => {
    cache = new MultiLayerCache({
      redisUrl: 'redis://localhost:6379',
      diskCachePath: '/tmp/test-cache',
    });
  });
  
  afterEach(async () => {
    await cache.close();
  });
  
  test('should set and get value from L1 cache', async () => {
    await cache.set('test-key', { data: 'test-value' });
    const result = await cache.get('test-key');
    
    expect(result).toEqual({ data: 'test-value' });
  });
  
  test('should invalidate cache entry', async () => {
    await cache.set('test-key', { data: 'test-value' });
    await cache.invalidate('test-key');
    const result = await cache.get('test-key');
    
    expect(result).toBeNull();
  });
  
  test('should track cache hit rate', async () => {
    await cache.set('key1', 'value1');
    await cache.get('key1'); // Hit
    await cache.get('key2'); // Miss
    
    const stats = cache.getStats();
    expect(stats.l1Hits).toBe(1);
    expect(stats.misses).toBe(1);
    expect(stats.hitRate).toBe(0.5);
  });
});

describe('ContentHasher', () => {
  test('should generate consistent hash for same content', () => {
    const hash1 = ContentHasher.hash('test content');
    const hash2 = ContentHasher.hash('test content');
    
    expect(hash1).toBe(hash2);
  });
  
  test('should generate different hash for different content', () => {
    const hash1 = ContentHasher.hash('content 1');
    const hash2 = ContentHasher.hash('content 2');
    
    expect(hash1).not.toBe(hash2);
  });
});
