import { Project, SourceFile, SyntaxKind } from 'ts-morph';
import * as path from 'path';

export interface SemanticNode {
  id: string;
  type: 'class' | 'function' | 'interface' | 'type' | 'variable';
  name: string;
  filePath: string;
  position: { line: number; character: number };
  dependencies: string[];
  dependents: string[];
  metadata: {
    isExported: boolean;
    complexity: number;
    importance: number;
    layer?: 'ui' | 'service' | 'data' | 'util';
  };
}

export class SemanticGraphBuilder {
  public graph: Map<string, SemanticNode> = new Map();
  private project: Project;
  
  constructor(private rootPath: string) {
    const tsConfigPath = path.join(rootPath, 'tsconfig.json');
    
    this.project = new Project({
      tsConfigFilePath: tsConfigPath,
      skipAddingFilesFromTsConfig: false,
    });
  }
  
  async buildGraph(): Promise<void> {
    console.log('Building semantic graph...');
    const startTime = Date.now();
    
    // Phase 1: Discover all symbols
    const sourceFiles = this.project.getSourceFiles();
    for (const file of sourceFiles) {
      this.processFile(file);
    }
    
    // Phase 2: Build dependency relationships
    this.buildDependencies();
    
    // Phase 3: Calculate importance scores
    this.calculateImportance();
    
    // Phase 4: Detect architectural layers
    this.detectLayers();
    
    console.log(`Graph built in ${Date.now() - startTime}ms`);
    console.log(`Total nodes: ${this.graph.size}`);
  }
  
  private processFile(file: SourceFile): void {
    const filePath = file.getFilePath();
    
    // Extract classes
    file.getClasses().forEach(cls => {
      const name = cls.getName();
      if (!name) return;
      
      const node: SemanticNode = {
        id: this.generateId(name, filePath),
        type: 'class',
        name,
        filePath,
        position: {
          line: cls.getStartLineNumber(),
          character: 0
        },
        dependencies: [],
        dependents: [],
        metadata: {
          isExported: cls.isExported(),
          complexity: this.calculateComplexity(cls),
          importance: 0,
        }
      };
      this.graph.set(node.id, node);
    });
    
    // Extract functions
    file.getFunctions().forEach(func => {
      const name = func.getName();
      if (!name) return;
      
      const node: SemanticNode = {
        id: this.generateId(name, filePath),
        type: 'function',
        name,
        filePath,
        position: {
          line: func.getStartLineNumber(),
          character: 0
        },
        dependencies: [],
        dependents: [],
        metadata: {
          isExported: func.isExported(),
          complexity: this.calculateComplexity(func),
          importance: 0,
        }
      };
      this.graph.set(node.id, node);
    });
    
    // Extract interfaces
    file.getInterfaces().forEach(iface => {
      const name = iface.getName();
      
      const node: SemanticNode = {
        id: this.generateId(name, filePath),
        type: 'interface',
        name,
        filePath,
        position: {
          line: iface.getStartLineNumber(),
          character: 0
        },
        dependencies: [],
        dependents: [],
        metadata: {
          isExported: iface.isExported(),
          complexity: 1,
          importance: 0,
        }
      };
      this.graph.set(node.id, node);
    });
  }
  
  private buildDependencies(): void {
    for (const [nodeId, node] of this.graph) {
      const file = this.project.getSourceFile(node.filePath);
      if (!file) continue;
      
      // Analyze imports
      file.getImportDeclarations().forEach(importDecl => {
        const moduleSpecifier = importDecl.getModuleSpecifierValue();
        
        importDecl.getNamedImports().forEach(namedImport => {
          const importedName = namedImport.getName();
          
          // Find the imported symbol in our graph
          for (const [importedId, importedNode] of this.graph) {
            if (importedNode.name === importedName) {
              node.dependencies.push(importedId);
              importedNode.dependents.push(nodeId);
            }
          }
        });
      });
    }
  }
  
  private calculateImportance(): void {
    const dampingFactor = 0.85;
    const iterations = 20;
    
    // Initialize all nodes with equal importance
    for (const node of this.graph.values()) {
      node.metadata.importance = 1.0 / this.graph.size;
    }
    
    // Iterative importance calculation (PageRank)
    for (let i = 0; i < iterations; i++) {
      const newImportance = new Map<string, number>();
      
      for (const [nodeId, node] of this.graph) {
        let importance = (1 - dampingFactor) / this.graph.size;
        
        // Add importance from dependent nodes
        for (const dependentId of node.dependents) {
          const dependent = this.graph.get(dependentId);
          if (dependent && dependent.dependencies.length > 0) {
            importance += dampingFactor * 
              (dependent.metadata.importance / dependent.dependencies.length);
          }
        }
        
        newImportance.set(nodeId, importance);
      }
      
      // Update importance scores
      for (const [nodeId, importance] of newImportance) {
        const node = this.graph.get(nodeId);
        if (node) {
          node.metadata.importance = importance;
        }
      }
    }
  }
  
  private detectLayers(): void {
    for (const node of this.graph.values()) {
      const pathLower = node.filePath.toLowerCase();
      
      if (pathLower.includes('/components/') || pathLower.includes('/ui/') || 
          pathLower.includes('/views/') || pathLower.includes('/pages/')) {
        node.metadata.layer = 'ui';
      } else if (pathLower.includes('/services/') || pathLower.includes('/api/') ||
                 pathLower.includes('/controllers/')) {
        node.metadata.layer = 'service';
      } else if (pathLower.includes('/models/') || pathLower.includes('/data/') ||
                 pathLower.includes('/entities/') || pathLower.includes('/repositories/')) {
        node.metadata.layer = 'data';
      } else if (pathLower.includes('/utils/') || pathLower.includes('/helpers/') ||
                 pathLower.includes('/lib/')) {
        node.metadata.layer = 'util';
      }
    }
  }
  
  private calculateComplexity(node: any): number {
    let complexity = 1;
    
    try {
      const ifStatements = node.getDescendantsOfKind?.(SyntaxKind.IfStatement) || [];
      const forStatements = node.getDescendantsOfKind?.(SyntaxKind.ForStatement) || [];
      const whileStatements = node.getDescendantsOfKind?.(SyntaxKind.WhileStatement) || [];
      const caseClauses = node.getDescendantsOfKind?.(SyntaxKind.CaseClause) || [];
      
      complexity += ifStatements.length + forStatements.length + 
                   whileStatements.length + caseClauses.length;
    } catch (error) {
      // If we can't calculate complexity, default to 1
    }
    
    return complexity;
  }
  
  private generateId(name: string, filePath: string): string {
    return `${filePath}::${name}`;
  }
  
  getNodesByImportance(topN: number): SemanticNode[] {
    return Array.from(this.graph.values())
      .sort((a, b) => b.metadata.importance - a.metadata.importance)
      .slice(0, topN);
  }
  
  getRelatedNodes(nodeId: string, depth: number = 2): SemanticNode[] {
    const visited = new Set<string>();
    const result: SemanticNode[] = [];
    
    const traverse = (id: string, currentDepth: number) => {
      if (currentDepth > depth || visited.has(id)) return;
      
      visited.add(id);
      const node = this.graph.get(id);
      if (!node) return;
      
      result.push(node);
      
      [...node.dependencies, ...node.dependents].forEach(relatedId => {
        traverse(relatedId, currentDepth + 1);
      });
    };
    
    traverse(nodeId, 0);
    return result;
  }
  
  getNode(nodeId: string): SemanticNode | undefined {
    return this.graph.get(nodeId);
  }
  
  getNodesByFile(filePath: string): SemanticNode[] {
    return Array.from(this.graph.values())
      .filter(node => node.filePath === filePath);
  }
}
