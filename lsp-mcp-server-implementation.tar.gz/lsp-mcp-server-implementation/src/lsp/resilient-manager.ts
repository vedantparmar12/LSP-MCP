import { LSPClient } from './client';
import { MultiLayerCache } from '../cache/multi-layer-cache';

export interface HealthStatus {
  isHealthy: boolean;
  lastCheck: number;
  consecutiveFailures: number;
}

export class ResilientLSPManager {
  private health: HealthStatus = {
    isHealthy: true,
    lastCheck: Date.now(),
    consecutiveFailures: 0,
  };
  
  private maxRetries = 3;
  private backoffMs = 1000;
  
  constructor(
    private lspClient: LSPClient,
    private cache: MultiLayerCache
  ) {
    this.startHealthMonitor();
  }
  
  async executeRequest<T>(
    method: string,
    params: any,
    cacheKey?: string
  ): Promise<T> {
    // Try cache first
    if (cacheKey) {
      const cached = await this.cache.get<T>(cacheKey);
      if (cached) {
        return cached;
      }
    }
    
    // Execute with retries
    for (let attempt = 0; attempt < this.maxRetries; attempt++) {
      try {
        const result = await this.lspClient.request<T>(method, params);
        
        // Success - reset failure count
        this.health.consecutiveFailures = 0;
        this.health.isHealthy = true;
        
        // Cache result
        if (cacheKey) {
          await this.cache.set(cacheKey, result);
        }
        
        return result;
      } catch (error) {
        console.error(`LSP request failed (attempt ${attempt + 1}):`, error);
        this.health.consecutiveFailures++;
        
        if (attempt < this.maxRetries - 1) {
          const delay = this.backoffMs * Math.pow(2, attempt);
          await this.sleep(delay);
        }
      }
    }
    
    throw new Error('All LSP request attempts failed');
  }
  
  getHealthStatus(): HealthStatus {
    return { ...this.health };
  }
  
  async shutdown(): Promise<void> {
    await this.lspClient.shutdown();
  }
  
  private startHealthMonitor(): void {
    setInterval(() => {
      this.health.lastCheck = Date.now();
      // TODO: Implement actual health check
    }, 30000);
  }
  
  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
