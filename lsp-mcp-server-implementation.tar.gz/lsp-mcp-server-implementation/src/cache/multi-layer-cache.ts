import { LRUCache } from 'lru-cache';
import Redis from 'ioredis';
import * as fs from 'fs/promises';
import * as crypto from 'crypto';
import * as path from 'path';

interface CacheEntry<T> {
  value: T;
  timestamp: number;
  hash: string;
}

export interface CacheConfig {
  redisUrl: string;
  diskCachePath: string;
  l1MaxSize?: number;
  l1MaxItems?: number;
  l1TTL?: number;
}

export interface CacheStats {
  l1Hits: number;
  l2Hits: number;
  l3Hits: number;
  misses: number;
  hitRate: number;
}

export class MultiLayerCache {
  private l1Cache: LRUCache<string, CacheEntry<any>>;
  private l2Cache: Redis;
  private l3CachePath: string;
  
  private stats = {
    l1Hits: 0,
    l2Hits: 0,
    l3Hits: 0,
    misses: 0,
  };
  
  constructor(config: CacheConfig) {
    // L1: In-memory LRU cache
    this.l1Cache = new LRUCache<string, CacheEntry<any>>({
      max: config.l1MaxItems || 1000,
      maxSize: config.l1MaxSize || 100 * 1024 * 1024, // 100MB default
      sizeCalculation: (entry) => {
        return JSON.stringify(entry.value).length;
      },
      ttl: config.l1TTL || 1000 * 60 * 60, // 1 hour default
    });
    
    // L2: Redis
    this.l2Cache = new Redis(config.redisUrl);
    
    // L3: Disk
    this.l3CachePath = config.diskCachePath;
  }
  
  async get<T>(key: string, contentHash?: string): Promise<T | null> {
    // Try L1
    const l1Entry = this.l1Cache.get(key);
    if (l1Entry && this.isValid(l1Entry, contentHash)) {
      this.stats.l1Hits++;
      return l1Entry.value as T;
    }
    
    // Try L2
    const l2Data = await this.l2Cache.get(key);
    if (l2Data) {
      try {
        const l2Entry: CacheEntry<T> = JSON.parse(l2Data);
        if (this.isValid(l2Entry, contentHash)) {
          this.stats.l2Hits++;
          
          // Promote to L1
          this.l1Cache.set(key, l2Entry);
          
          return l2Entry.value;
        }
      } catch (error) {
        console.error('Failed to parse L2 cache entry:', error);
      }
    }
    
    // Try L3
    try {
      const l3Path = this.getL3Path(key);
      const l3Data = await fs.readFile(l3Path, 'utf-8');
      const l3Entry: CacheEntry<T> = JSON.parse(l3Data);
      
      if (this.isValid(l3Entry, contentHash)) {
        this.stats.l3Hits++;
        
        // Promote to L2 and L1
        await this.l2Cache.setex(key, 3600, JSON.stringify(l3Entry));
        this.l1Cache.set(key, l3Entry);
        
        return l3Entry.value;
      }
    } catch (error) {
      // L3 miss or error - this is expected
    }
    
    this.stats.misses++;
    return null;
  }
  
  async set<T>(key: string, value: T, contentHash?: string): Promise<void> {
    const entry: CacheEntry<T> = {
      value,
      timestamp: Date.now(),
      hash: contentHash || this.hashContent(value),
    };
    
    // Write to all layers
    this.l1Cache.set(key, entry);
    
    await this.l2Cache.setex(
      key,
      3600, // 1 hour TTL
      JSON.stringify(entry)
    );
    
    const l3Path = this.getL3Path(key);
    await fs.mkdir(path.dirname(l3Path), { recursive: true });
    await fs.writeFile(l3Path, JSON.stringify(entry));
  }
  
  async invalidate(key: string): Promise<void> {
    this.l1Cache.delete(key);
    await this.l2Cache.del(key);
    
    try {
      await fs.unlink(this.getL3Path(key));
    } catch (error) {
      // Ignore if file doesn't exist
    }
  }
  
  async invalidateByPattern(pattern: string): Promise<void> {
    const regex = new RegExp(pattern);
    
    // L1
    for (const key of this.l1Cache.keys()) {
      if (regex.test(key)) {
        this.l1Cache.delete(key);
      }
    }
    
    // L2
    const keys = await this.l2Cache.keys(pattern);
    if (keys.length > 0) {
      await this.l2Cache.del(...keys);
    }
  }
  
  async has(key: string): Promise<boolean> {
    if (this.l1Cache.has(key)) {
      return true;
    }
    
    const l2Exists = await this.l2Cache.exists(key);
    if (l2Exists) {
      return true;
    }
    
    try {
      await fs.access(this.getL3Path(key));
      return true;
    } catch {
      return false;
    }
  }
  
  private isValid<T>(entry: CacheEntry<T>, expectedHash?: string): boolean {
    const age = Date.now() - entry.timestamp;
    const maxAge = 24 * 60 * 60 * 1000; // 24 hours
    
    if (age > maxAge) return false;
    
    if (expectedHash && entry.hash !== expectedHash) {
      return false;
    }
    
    return true;
  }
  
  private hashContent(content: any): string {
    const str = JSON.stringify(content);
    return crypto.createHash('sha256').update(str).digest('hex');
  }
  
  private getL3Path(key: string): string {
    const hash = crypto.createHash('md5').update(key).digest('hex');
    const subdir = hash.substring(0, 2);
    return path.join(this.l3CachePath, subdir, `${hash}.json`);
  }
  
  getStats(): CacheStats {
    const total = this.stats.l1Hits + this.stats.l2Hits + 
                  this.stats.l3Hits + this.stats.misses;
    
    return {
      ...this.stats,
      hitRate: total > 0 ? 
        ((this.stats.l1Hits + this.stats.l2Hits + this.stats.l3Hits) / total) : 0,
    };
  }
  
  async close(): Promise<void> {
    await this.l2Cache.quit();
  }
}
