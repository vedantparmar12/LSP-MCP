import * as chokidar from 'chokidar';
import { MultiLayerCache } from './multi-layer-cache';
import { ContentHasher } from './content-hash';

export class CacheInvalidationManager {
  private watcher: chokidar.FSWatcher | null = null;
  private fileHashes = new Map<string, string>();
  
  constructor(
    private cache: MultiLayerCache,
    private workspaceRoot: string
  ) {}
  
  start(): void {
    this.watcher = chokidar.watch(this.workspaceRoot, {
      ignored: /(^|[\/\\])\../, // Ignore hidden files
      persistent: true,
      ignoreInitial: true,
    });
    
    this.watcher
      .on('change', (path) => this.handleFileChanged(path))
      .on('unlink', (path) => this.handleFileDeleted(path))
      .on('add', (path) => this.handleFileAdded(path));
  }
  
  stop(): void {
    if (this.watcher) {
      this.watcher.close();
      this.watcher = null;
    }
  }
  
  private async handleFileChanged(filePath: string): Promise<void> {
    console.log(`File changed: ${filePath}`);
    
    // Invalidate all cache entries for this file
    await this.cache.invalidateByPattern(`.*${filePath}.*`);
    
    // Update hash
    // Note: In production, you'd read the file here
    // this.fileHashes.set(filePath, newHash);
  }
  
  private async handleFileDeleted(filePath: string): Promise<void> {
    console.log(`File deleted: ${filePath}`);
    
    // Invalidate all cache entries for this file
    await this.cache.invalidateByPattern(`.*${filePath}.*`);
    
    // Remove hash
    this.fileHashes.delete(filePath);
  }
  
  private async handleFileAdded(filePath: string): Promise<void> {
    console.log(`File added: ${filePath}`);
    // No invalidation needed for new files
  }
}
