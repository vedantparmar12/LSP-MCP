import { spawn, ChildProcess } from 'child_process';
import * as os from 'os';
import * as path from 'path';
import * as fs from 'fs/promises';

export interface SecurityConfig {
  workspaceRoot: string;
  maxMemoryMB: number;
  maxCPUPercent: number;
  allowedPaths: string[];
  blockedPaths: string[];
  enableNetworking: boolean;
}

export interface ResourceLimits {
  maxMemory: string;
  maxCPU: number;
  maxFileDescriptors: number;
  maxProcesses: number;
}

export class SecuritySandbox {
  private allowedPaths: Set<string>;
  private blockedPaths: Set<string>;
  
  constructor(private config: SecurityConfig) {
    this.allowedPaths = new Set([
      path.resolve(config.workspaceRoot),
      ...config.allowedPaths.map(p => path.resolve(p))
    ]);
    
    this.blockedPaths = new Set([
      '/etc',
      '/var',
      '/usr',
      '/bin',
      '/sbin',
      ...config.blockedPaths.map(p => path.resolve(p))
    ]);
    
    // Add user-specific sensitive paths
    if (process.env.HOME) {
      this.blockedPaths.add(path.join(process.env.HOME, '.ssh'));
      this.blockedPaths.add(path.join(process.env.HOME, '.aws'));
      this.blockedPaths.add(path.join(process.env.HOME, '.config'));
    }
  }
  
  validateFileAccess(filePath: string): boolean {
    const resolved = path.resolve(filePath);
    
    // Check if path is blocked
    for (const blocked of this.blockedPaths) {
      if (resolved.startsWith(blocked)) {
        console.warn(`Access denied to blocked path: ${filePath}`);
        return false;
      }
    }
    
    // Check if path is in allowed roots
    for (const allowed of this.allowedPaths) {
      if (resolved.startsWith(allowed)) {
        return true;
      }
    }
    
    console.warn(`Access denied to path outside workspace: ${filePath}`);
    return false;
  }
  
  validateOrThrow(filePath: string): void {
    if (!this.validateFileAccess(filePath)) {
      throw new Error(
        `Access denied: ${filePath} is outside allowed workspace or in blocked path`
      );
    }
  }
  
  // Platform-specific sandboxing
  async spawnSandboxed(
    command: string,
    args: string[],
    options?: any
  ): Promise<ChildProcess> {
    const platform = os.platform();
    
    switch (platform) {
      case 'linux':
        return this.spawnLinuxSandbox(command, args, options);
      case 'darwin':
        return this.spawnMacOSSandbox(command, args, options);
      case 'win32':
        return this.spawnWindowsSandbox(command, args, options);
      default:
        console.warn(`No sandbox available for platform: ${platform}`);
        return spawn(command, args, options);
    }
  }
  
  private spawnLinuxSandbox(
    command: string,
    args: string[],
    options?: any
  ): ChildProcess {
    // Use unshare for namespace isolation
    const sandboxArgs = [
      'unshare',
      '--mount',
      '--pid',
      '--net', // Network namespace (isolated)
      '--fork',
      '--',
      command,
      ...args
    ];
    
    return spawn(sandboxArgs[0], sandboxArgs.slice(1), {
      ...options,
      env: this.getSanitizedEnv(),
    });
  }
  
  private spawnMacOSSandbox(
    command: string,
    args: string[],
    options?: any
  ): ChildProcess {
    // Use sandbox-exec on macOS
    const profile = this.generateMacOSSandboxProfile();
    
    const sandboxArgs = [
      'sandbox-exec',
      '-p',
      profile,
      command,
      ...args
    ];
    
    return spawn(sandboxArgs[0], sandboxArgs.slice(1), options);
  }
  
  private spawnWindowsSandbox(
    command: string,
    args: string[],
    options?: any
  ): ChildProcess {
    // Windows sandboxing is more limited
    // Use job objects via node (requires additional setup)
    console.warn('Windows sandboxing is limited. Consider using Docker.');
    return spawn(command, args, options);
  }
  
  private generateMacOSSandboxProfile(): string {
    const allowedPaths = Array.from(this.allowedPaths)
      .map(p => `(allow file-read* (subpath "${p}"))
(allow file-write* (subpath "${p}"))`)
      .join('\n');
    
    return `
(version 1)
(deny default)
(allow process*)
${allowedPaths}
(deny file-read* (subpath "/etc"))
(deny file-read* (subpath "/Users"))
${this.config.enableNetworking ? '(allow network*)' : '(deny network*)'}
    `.trim();
  }
  
  private getSanitizedEnv(): NodeJS.ProcessEnv {
    return {
      PATH: '/usr/bin:/bin',
      HOME: '/tmp',
      TMPDIR: '/tmp',
    };
  }
  
  // Docker-based sandboxing (recommended for production)
  async spawnDockerSandbox(
    image: string,
    command: string[],
    volumeMounts?: Record<string, string>
  ): Promise<ChildProcess> {
    const dockerArgs = [
      'run',
      '--rm',
      '-i',
      '--network=none', // No network access
      `--memory=${this.config.maxMemoryMB}m`,
      `--cpus=${this.config.maxCPUPercent / 100}`,
      '--pids-limit=100',
      '--read-only',
      '--tmpfs=/tmp:size=100m',
    ];
    
    // Add volume mounts
    if (volumeMounts) {
      for (const [host, container] of Object.entries(volumeMounts)) {
        dockerArgs.push('-v', `${host}:${container}:ro`);
      }
    }
    
    // Add workspace mount
    dockerArgs.push(
      '-v',
      `${this.config.workspaceRoot}:/workspace:ro`,
      '-w',
      '/workspace'
    );
    
    dockerArgs.push(image, ...command);
    
    return spawn('docker', dockerArgs, {
      stdio: ['pipe', 'pipe', 'pipe'],
    });
  }
}
