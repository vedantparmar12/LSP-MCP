import * as winston from 'winston';
import * as path from 'path';

export interface SecurityEvent {
  type: 'file_access' | 'network_attempt' | 'resource_limit' | 'permission_denied' | 'process_spawn';
  pid: number;
  timestamp: Date;
  details: Record<string, any>;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export class SecurityAuditor {
  private logger: winston.Logger;
  private alertThreshold: number = 0;
  private eventCounts = new Map<string, number>();
  
  constructor(logPath: string = '/tmp/lsp-mcp-security.log') {
    this.logger = winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        // Main security log
        new winston.transports.File({
          filename: logPath,
          maxsize: 10 * 1024 * 1024, // 10MB
          maxFiles: 10,
        }),
        
        // High-severity alerts log
        new winston.transports.File({
          filename: path.join(path.dirname(logPath), 'security-alerts.log'),
          level: 'warn',
          maxsize: 5 * 1024 * 1024,
          maxFiles: 5,
        }),
        
        // Console output for critical events
        new winston.transports.Console({
          level: 'error',
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          ),
        }),
      ],
    });
  }
  
  logEvent(event: SecurityEvent): void {
    const logLevel = this.getLogLevel(event.severity);
    
    this.logger.log(logLevel, 'Security event', {
      event_type: event.type,
      pid: event.pid,
      severity: event.severity,
      timestamp: event.timestamp.toISOString(),
      ...event.details,
    });
    
    // Track event frequency
    this.trackEventFrequency(event);
    
    // Alert on critical events
    if (event.severity === 'critical') {
      this.sendAlert(event);
    }
    
    // Alert on suspicious patterns
    this.detectSuspiciousPatterns(event);
  }
  
  logFileAccess(
    pid: number,
    filePath: string,
    action: 'read' | 'write' | 'execute',
    allowed: boolean
  ): void {
    this.logEvent({
      type: 'file_access',
      pid,
      timestamp: new Date(),
      severity: allowed ? 'low' : 'medium',
      details: {
        path: filePath,
        action,
        allowed,
      },
    });
  }
  
  logNetworkAttempt(
    pid: number,
    destination: string,
    port: number,
    allowed: boolean
  ): void {
    this.logEvent({
      type: 'network_attempt',
      pid,
      timestamp: new Date(),
      severity: allowed ? 'low' : 'high',
      details: {
        destination,
        port,
        allowed,
      },
    });
  }
  
  logResourceLimit(
    pid: number,
    resource: string,
    limit: string | number,
    actual: string | number,
    action: 'warn' | 'kill'
  ): void {
    this.logEvent({
      type: 'resource_limit',
      pid,
      timestamp: new Date(),
      severity: action === 'kill' ? 'high' : 'medium',
      details: {
        resource,
        limit,
        actual,
        action,
      },
    });
  }
  
  logPermissionDenied(
    pid: number,
    resource: string,
    reason: string
  ): void {
    this.logEvent({
      type: 'permission_denied',
      pid,
      timestamp: new Date(),
      severity: 'medium',
      details: {
        resource,
        reason,
      },
    });
  }
  
  logProcessSpawn(
    parentPid: number,
    childPid: number,
    command: string,
    args: string[]
  ): void {
    this.logEvent({
      type: 'process_spawn',
      pid: parentPid,
      timestamp: new Date(),
      severity: 'low',
      details: {
        child_pid: childPid,
        command,
        args,
      },
    });
  }
  
  private getLogLevel(severity: string): string {
    switch (severity) {
      case 'low':
        return 'info';
      case 'medium':
        return 'warn';
      case 'high':
        return 'error';
      case 'critical':
        return 'error';
      default:
        return 'info';
    }
  }
  
  private sendAlert(event: SecurityEvent): void {
    console.error('🚨 SECURITY ALERT:', {
      type: event.type,
      severity: event.severity,
      details: event.details,
      timestamp: event.timestamp.toISOString(),
    });
    
    // In production, you would:
    // - Send to monitoring system (Datadog, New Relic, etc.)
    // - Send to PagerDuty or similar
    // - Send email/SMS to security team
    // - Trigger incident response workflow
  }
  
  private trackEventFrequency(event: SecurityEvent): void {
    const key = `${event.type}:${event.pid}`;
    const count = (this.eventCounts.get(key) || 0) + 1;
    this.eventCounts.set(key, count);
    
    // Reset counts every hour
    setTimeout(() => {
      this.eventCounts.delete(key);
    }, 60 * 60 * 1000);
  }
  
  private detectSuspiciousPatterns(event: SecurityEvent): void {
    const key = `${event.type}:${event.pid}`;
    const count = this.eventCounts.get(key) || 0;
    
    // Alert on repeated permission denials
    if (event.type === 'permission_denied' && count > 10) {
      this.sendAlert({
        ...event,
        severity: 'high',
        details: {
          ...event.details,
          pattern: 'repeated_permission_denials',
          count,
        },
      });
    }
    
    // Alert on rapid file access attempts
    if (event.type === 'file_access' && !event.details.allowed && count > 20) {
      this.sendAlert({
        ...event,
        severity: 'critical',
        details: {
          ...event.details,
          pattern: 'possible_directory_traversal_attack',
          count,
        },
      });
    }
    
    // Alert on network attempts when networking is disabled
    if (event.type === 'network_attempt' && !event.details.allowed) {
      this.sendAlert({
        ...event,
        severity: 'critical',
        details: {
          ...event.details,
          pattern: 'unauthorized_network_access_attempt',
        },
      });
    }
  }
  
  async getAuditReport(since?: Date): Promise<any> {
    // In production, you'd query the log files or database
    // For now, return a simple summary
    
    const summary = {
      totalEvents: Array.from(this.eventCounts.values()).reduce((a, b) => a + b, 0),
      eventsByType: {} as Record<string, number>,
      topProcesses: [] as Array<{ pid: number; eventCount: number }>,
    };
    
    // Group by event type
    for (const [key, count] of this.eventCounts.entries()) {
      const [type] = key.split(':');
      summary.eventsByType[type] = (summary.eventsByType[type] || 0) + count;
    }
    
    return summary;
  }
  
  async close(): Promise<void> {
    this.logger.close();
  }
}
